export const ImageList = [
	{
		name: 'Roadmap',
		image: 'https://map.map4d.vn/mapAppRoot/image/mapTypeSelect/roadMap.png',
		new: true
	},
	{
		name: 'Raster',
		image: 'https://map.map4d.vn/mapAppRoot/image/mapTypeSelect/raster.png',
		new: false
	},
	{
		name: 'Satellite',
		image: 'https://map.map4d.vn/mapAppRoot/image/mapTypeSelect/satellite.png',
		new: true
	},
	{
		name: 'Map3d',
		image: 'https://map.map4d.vn/mapAppRoot/image/mapTypeSelect/map3d.png',
		new: false
	}
]
