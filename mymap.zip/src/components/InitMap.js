const InitMap = () => {
	return <div></div>
}

export default InitMap

// "eslintConfig": {
//   "extends": [
//     "react-app",
//     "react-app/jest"
//   ]
// },
