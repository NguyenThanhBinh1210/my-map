import React, { useState } from "react";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import Stack from "@mui/material/Stack";
import CircleOutlinedIcon from "@mui/icons-material/CircleOutlined";
import PlaceIcon from "@mui/icons-material/Place";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import SwapVertIcon from "@mui/icons-material/SwapVert";
import { Box, Button, IconButton, Tooltip, Typography } from "@mui/material";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import CloseIcon from "@mui/icons-material/Close"; 
import AddLocationAltIcon from "@mui/icons-material/AddLocationAlt";
import { Container, Draggable } from "react-smooth-dnd";
import DeleteIcon from "../DeleteIcon/DeleteIcon";

const InstructionMain = () => {
  const [addNewLocation, setAddNewLocation] = useState(false);
  const [value1, setValue1] = useState("");
  const [value2, setValue2] = useState("");
  const [value3, setValue3] = useState("");
  const onDrop = () => {
    setValue1(value2);
    setValue2(value1);
  };
  const handleAddLocation = () => {
    setAddNewLocation(!addNewLocation);
    // setValue3("");
  };
  const handleRemoveLocation1 = () => {
    setValue1(value2);
    setValue2(value3);
    setValue3("");
    setAddNewLocation(false);
  };
  const handleRemoveLocation2 = () => {
    setValue2(value3);
    setValue3("");
    setAddNewLocation(false);
  };

  const handleRemoveLocation3 = () => {
    setValue3("");
    setAddNewLocation(false);
  };

  const top100Films = [
    { label: "Bình" },
    { label: "Sơn" },
    { label: "Tú" },
    { label: "Garena" },
    { label: "Discord" },
  ];

  return (
    <>
      <Container dragHandleSelector=".drag-handle" lockAxis="y" onDrop={onDrop}>
        <Draggable className="drag-handle">
          <div className="showdeleteicon">
            <Stack
              direction="row"
              spacing={1}
              sx={{
                width: 400,
                display: "flex",
                alignItems: "flex-end",
                marginLeft: "10px",
                paddingLeft: "30px",
                zIndex: 100,
                position: "relative",
              }}
            >
              <Autocomplete
                className="autocomplete-css"
                sx={{
                  width: 320,
                  display: "flex",
                  "& button:first-child": { display: "none" },
                }}
                id="open-on-focus"
                value={value1}
                onChange={(e) => setValue1(e.currentTarget.childNodes[1].data)}
                options={top100Films}
                renderOption={(props, option) => (
                  <Box
                    component="li"
                    sx={{ "& > img": { mr: 2, flexShrink: 0 } }}
                    {...props}
                  >
                    <LocationOnIcon
                      sx={{
                        marginRight: "10px",
                        color: "rgb(80, 143, 244)",
                      }}
                    />
                    {option.label}
                  </Box>
                )}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    placeholder="Chọn điểm đi hoặc click trên bản đồ"
                    variant="standard"
                    sx={{
                      color: "white",
                    }}
                  />
                )}
              />
              {value1 !== "" && (
                <Tooltip title="Xóa">
                  <IconButton
                    onClick={() => setValue1("")}
                    sx={{
                      position: "absolute",
                      right: "100px",
                      top: "12px",
                      width: 25,
                      height: 25,
                    }}
                  >
                    <CloseIcon />
                  </IconButton>
                </Tooltip>
              )}
              <DeleteIcon
                handleRemoveLocation={handleRemoveLocation1}
                title="Xóa địa điểm này"
              />
            </Stack>
            {/* {addNewLocation && (
              <DeleteIcon
                handleAddLocation={handleAddLocation}
                title="Xóa địa điểm này"
              />
            )} */}
          </div>
        </Draggable>
        <Draggable className="drag-handle">
          <div className="showdeleteicon">
            <Stack
              direction="row"
              spacing={1}
              sx={{
                width: 400,
                display: "flex",
                alignItems: "flex-end",
                marginLeft: "10px",
                paddingLeft: "30px",
                zIndex: 100,
                position: "relative",
              }}
            >
              <Autocomplete
                className="autocomplete-css"
                sx={{
                  width: 320,
                  display: "flex",
                  "& button:first-child": { display: "none" },
                }}
                id="open-on-focus"
                value={value2}
                onChange={(e) => setValue2(e.currentTarget.childNodes[1].data)}
                options={top100Films}
                renderOption={(props, option) => (
                  <Box
                    component="li"
                    sx={{ "& > img": { mr: 2, flexShrink: 0 } }}
                    {...props}
                  >
                    <LocationOnIcon
                      sx={{
                        marginRight: "10px",
                        color: "rgb(80, 143, 244)",
                      }}
                    />
                    {option.label}
                  </Box>
                )}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    placeholder="Chọn điểm đến"
                    variant="standard"
                    sx={{
                      color: "white",
                    }}
                  />
                )}
              />
              {value2 !== "" && (
                <Tooltip title="Xóa">
                  <IconButton
                    onClick={() => setValue2("")}
                    sx={{
                      position: "absolute",
                      right: "100px",
                      top: "12px",
                      width: 25,
                      height: 25,
                    }}
                  >
                    <CloseIcon />
                  </IconButton>
                </Tooltip>
              )}
              <DeleteIcon
                handleRemoveLocation={handleRemoveLocation2}
                title="Xóa địa điểm này"
              />
            </Stack>
            {/* {addNewLocation && (
              <DeleteIcon
                handleRemoveLocation2={handleRemoveLocation2}
                title="Xóa địa điểm này"
              />
            )} */}
          </div>
        </Draggable>
        {value1 && value2 ? (
          <Stack
            onClick={handleAddLocation}
            sx={{
              display: addNewLocation ? "none" : "flex",
              alignItems: "center",
              flexDirection: "row",
              cursor: "pointer",
            }}
          >
            <Tooltip title="Thêm điểm đến">
              <AddLocationAltIcon
                sx={{
                  color: "white",
                  paddingRight: "10px",
                  marginLeft: "10px",
                  fontSize: "20px",
                }}
              />
            </Tooltip>
            <Typography color="white" variant="subtitle1">
              Thêm điểm đến
            </Typography>
          </Stack>
        ) : null}
        {addNewLocation && (
          <Draggable className="drag-handle">
            <div className="showdeleteicon">
              <Stack
                direction="row"
                spacing={1}
                sx={{
                  width: 400,
                  display: "flex",
                  alignItems: "flex-end",
                  marginLeft: "10px",
                  paddingLeft: "30px",
                  zIndex: 100,
                  position: "relative",
                }}
              >
                <Autocomplete
                  className="autocomplete-css"
                  sx={{
                    width: 320,
                    display: "flex",
                    "& button:first-child": { display: "none" },
                  }}
                  id="open-on-focus"
                  value={value3}
                  onChange={(e) =>
                    setValue3(e.currentTarget.childNodes[1].data)
                  }
                  options={top100Films}
                  renderOption={(props, option) => (
                    <Box
                      component="li"
                      sx={{ "& > img": { mr: 2, flexShrink: 0 } }}
                      {...props}
                    >
                      <LocationOnIcon
                        sx={{
                          marginRight: "10px",
                          color: "rgb(80, 143, 244)",
                        }}
                      />
                      {option.label}
                    </Box>
                  )}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      placeholder="Chọn điểm đến"
                      variant="standard"
                      sx={{
                        color: "white",
                      }}
                    />
                  )}
                />
                {value3 !== "" && (
                  <Tooltip title="Xóa">
                    <IconButton
                      onClick={() => setValue3("")}
                      sx={{
                        position: "absolute",
                        right: "100px",
                        top: "12px",
                        width: 25,
                        height: 25,
                      }}
                    >
                      <CloseIcon />
                    </IconButton>
                  </Tooltip>
                )}
                <DeleteIcon
                  handleRemoveLocation={handleRemoveLocation3}
                  title="Xóa địa điểm này"
                />
              </Stack>
            </div>
          </Draggable>
        )}
      </Container>
      <>
        <MoreVertIcon
          fontSize="small"
          sx={{
            color: "white",
            position: "absolute",
            top: "90px",
            left: "19px",
          }}
        />
        {!addNewLocation && (
          <Tooltip
            title="Đảo ngược điểm xuất phát và điểm đến"
            arrow
            placement="right"
          >
            <SwapVertIcon
              fontSize="large"
              onClick={value1 && value2 ? onDrop : null}
              sx={{
                color: "white",
                position: "absolute",
                top: "90px",
                right: "10px",
                zIndex: "1000",
                cursor: "pointer",
              }}
            />
          </Tooltip>
        )}
        <CircleOutlinedIcon
          fontSize="small"
          sx={{
            color: "white",
            paddingBottom: "10px",
            display: "flex",
            position: "absolute",
            top: "70px",
            left: "19px",
          }}
        />
        {addNewLocation ? (
          <CircleOutlinedIcon
            fontSize="small"
            sx={{
              color: "white",
              paddingBottom: "10px",
              position: "absolute",
              top: "115px",
              left: "19px",
            }}
          />
        ) : (
          <PlaceIcon
            fontSize="small"
            sx={{
              color: "white",
              paddingBottom: "10px",
              position: "absolute",
              top: "115px",
              left: "19px",
            }}
          />
        )}
        {addNewLocation && (
          <>
            <PlaceIcon
              fontSize="small"
              sx={{
                color: "white",
                paddingBottom: "10px",
                position: "absolute",
                top: "160px",
                left: "19px",
              }}
            />
            <MoreVertIcon
              fontSize="small"
              sx={{
                color: "white",
                position: "absolute",
                top: "137px",
                left: "19px",
              }}
            />
          </>
        )}
      </>
      <Stack
        direction="row"
        sx={{
          display: "flex",
          width: "100%",
          maxWidth: "300px",
          backgroundColor: "white",
          margin: "15px auto",
          borderRadius: "5px",
          overflow: "hidden",
        }}
      >
        <Box
          variant="contained"
          sx={{
            backgroundColor: "white",
            color: "rgb(123, 123, 123)",
            fontSize: "12px",
            width: "80px",
          }}
        >
          <button
            className="button-search"
            style={{
              width: "100%",
              color: "rgb(123, 123, 123)",
              padding: "10px",
              outline: "none",
              border: "none",
              cursor: "pointer",
              transition: "all 300ms ease",
            }}
          >
            Tìm kiếm
          </button>
        </Box>
        <select
          defaultValue="Cân bằng"
          id="selection"
          style={{
            flex: "1",
            outline: "none",
            border: "1px solid #ccc",
          }}
        >
          <option value="volvo">Ngắn nhất</option>
          <option value="saab">Nhanh nhất</option>
          <option value="vw">Cân bằng</option>
        </select>
      </Stack>
    </>
  );
};

export default InstructionMain;
